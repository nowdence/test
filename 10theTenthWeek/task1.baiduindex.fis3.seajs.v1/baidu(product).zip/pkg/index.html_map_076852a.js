seajs.config({alias:{
  "sea-modules/jquery/jquery/1.10.1/jquery": "/sea-modules/jquery/jquery/1.10.1/jquery_f305da4",
  "static/baiduindex/src/js/index": "/static/baiduindex/src/js/index_bdd82fd",
  "static/baiduindex/src/js/main": "/static/baiduindex/src/js/main_99b4694"
}});